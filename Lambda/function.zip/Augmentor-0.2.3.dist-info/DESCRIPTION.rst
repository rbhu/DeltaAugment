Image augmentation library for Machine Learning


